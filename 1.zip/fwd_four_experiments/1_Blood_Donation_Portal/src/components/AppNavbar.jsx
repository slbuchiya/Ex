import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link, NavLink } from 'react-router-dom';
export default function AppNavbar(){ return <Navbar bg="danger" variant="dark" expand="md"><Container><Navbar.Brand as={Link} to="/">🩸 Blood Donation Portal</Navbar.Brand><Navbar.Toggle aria-controls="main-nav"/><Navbar.Collapse id="main-nav"><Nav className="ms-auto"><Nav.Link as={NavLink} to="/" end>Home</Nav.Link><Nav.Link as={NavLink} to="/camps">Camps</Nav.Link><Nav.Link as={NavLink} to="/about">About</Nav.Link></Nav></Navbar.Collapse></Container></Navbar>; }
