import { Card, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
export default function CampCard({id,name,venue,date,time}){ const navigate=useNavigate(); return <Card className="h-100 shadow-sm camp-card"><Card.Body><Card.Title>{name}</Card.Title><Card.Text><b>Venue:</b> {venue}</Card.Text><Card.Text><b>Date:</b> {date}</Card.Text><Card.Text><b>Time:</b> {time}</Card.Text><Button variant="danger" onClick={()=>navigate(`/camps/${id}`)}>View Details</Button></Card.Body></Card>; }
