import { Container, Row, Col } from 'react-bootstrap'; import CampCard from '../components/CampCard.jsx'; import camps from '../data/camps.js';
export default function Camps(){return <Container className="py-4"><h2 className="text-center mb-4">Available Camps</h2><Row className="g-3">{camps.map(c=><Col key={c.id} xs={12} md={6} lg={4}><CampCard {...c}/></Col>)}</Row></Container>}
