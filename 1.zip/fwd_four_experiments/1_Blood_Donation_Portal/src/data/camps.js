const camps = [
 { id: 1, name: 'Hope Blood Donation Camp', venue: 'Sunrise Community Hall, Green Park Road', date: '15 September 2026', time: '9:00 AM to 2:00 PM' },
 { id: 2, name: 'Red Life Donor Drive', venue: 'Harmony Convention Center, Lake View Avenue', date: '20 September 2026', time: '10:00 AM to 3:00 PM' },
 { id: 3, name: 'Helping Hands Blood Camp', venue: 'CarePoint Health Center, Rose Garden Street', date: '25 September 2026', time: '8:00 AM to 1:00 PM' }
];
export default camps;
