# Assignment 1 — Blood Donation Camp Portal

### Run
```bash
npm install
npm run dev
```
Open the local URL shown by Vite. The app includes Home, Camps, dynamic Camp Details, donor registration, About and 404 routes. Registration is a front-end demonstration and does not save data to a server.
