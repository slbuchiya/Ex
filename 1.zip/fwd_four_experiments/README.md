# FWD Assignments 1–4 — Complete Source Code

Each assignment is in its own folder. Read each folder's README before running it.

## Requirements
- Node.js 20+ and npm for Assignments 1 and 3
- MongoDB Server + `mongosh` for Assignments 2 and 4

The MongoDB scripts use the databases, collections, fields and operations listed in the supplied assignment PDFs. Assignment 4's PDF did not expose the five sample menu records in its text layer, so `food_menu.js` includes clearly editable sample records matching the required fields (`itemId`, `name`, `category`, `price`, `rating`).
