// FWD Assignment 4 — MongoDB Food Menu
// Run: mongosh < food_menu.js
// Database: foodDB | Collection: menu
use foodDB;
db.menu.drop();
db.createCollection("menu");
db.menu.createIndex({ itemId: 1 }, { unique: true });

// The supplied PDF's embedded table values were not readable in its extracted text.
// These five editable sample documents use the required fields and IDs/queries.
db.menu.insertMany([
  { itemId: 101, name: "Veg Burger", category: "Burger", price: 180, rating: 4.1 },
  { itemId: 102, name: "Margherita Pizza", category: "Pizza", price: 280, rating: 4.2 },
  { itemId: 103, name: "Paneer Pizza", category: "Pizza", price: 350, rating: 4.5 },
  { itemId: 104, name: "French Fries", category: "Sides", price: 150, rating: 3.9 },
  { itemId: 105, name: "Cold Coffee", category: "Beverage", price: 220, rating: 4.0 }
]);
print("3. All menu items"); db.menu.find().forEach(printjson);
print("4. Price < 300"); db.menu.find({ price: { $lt: 300 } }).forEach(printjson);
print('5. Category is Pizza'); db.menu.find({ category: "Pizza" }).forEach(printjson);
print("6. Rating >= 4.0"); db.menu.find({ rating: { $gte: 4.0 } }).forEach(printjson);
print("7. Increase itemId 102 price by 20"); printjson(db.menu.updateOne({ itemId: 102 }, { $inc: { price: 20 } }));
printjson(db.menu.findOne({ itemId: 102 }));
print("8. Delete itemId 105"); printjson(db.menu.deleteOne({ itemId: 105 }));
print("Remaining menu items"); db.menu.find().forEach(printjson);
