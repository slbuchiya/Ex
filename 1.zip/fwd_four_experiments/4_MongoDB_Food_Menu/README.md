# Assignment 4 — MongoDB Food Menu

**Database:** `foodDB` · **Collection:** `menu`

Start MongoDB Server, then run `mongosh < food_menu.js` from this folder. This resets `menu`, creates a unique index on `itemId`, inserts five sample documents, and runs the assignment queries: all records, price below ₹300, Pizza category, rating at least 4.0, increase item 102 price by ₹20, and delete item 105.

**Important:** the five food rows in the uploaded assignment PDF were present as images and their values were not available in the extracted text. The records in this script are sample data; edit them to match your original table if required. The query operations and field names follow the assignment instructions.
