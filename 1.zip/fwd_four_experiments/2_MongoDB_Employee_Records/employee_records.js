// FWD Assignment 2 — MongoDB Employee Records
// Run with: mongosh < employee_records.js
// Database: companyDB | Collection: employees
use companyDB;

// Safe to re-run: reset the collection for a clean demonstration.
db.employees.drop();
db.createCollection("employees");

// 1–2. Insert five employee records.
db.employees.insertMany([
  { empId: 101, name: "Aarav Patel", department: "IT", salary: 45000, experience: 4 },
  { empId: 102, name: "Diya Shah", department: "HR", salary: 35000, experience: 2 },
  { empId: 103, name: "Kabir Mehta", department: "Finance", salary: 50000, experience: 5 },
  { empId: 104, name: "Meera Joshi", department: "IT", salary: 38000, experience: 3 },
  { empId: 105, name: "Rohan Desai", department: "Marketing", salary: 42000, experience: 6 }
]);

// 3. Retrieve all employees.
print("3. All employees"); db.employees.find().forEach(printjson);
// 4. Salary >= 40000.
print("4. Salary >= 40000"); db.employees.find({ salary: { $gte: 40000 } }).forEach(printjson);
// 5. Department is not HR.
print("5. Department != HR"); db.employees.find({ department: { $ne: "HR" } }).forEach(printjson);
// 6. Department is IT or Finance.
print("6. IT or Finance"); db.employees.find({ department: { $in: ["IT", "Finance"] } }).forEach(printjson);
// 7. Increase empId 104 salary by 5000.
print("7. Update empId 104 salary +5000"); printjson(db.employees.updateOne({ empId: 104 }, { $inc: { salary: 5000 } }));
printjson(db.employees.findOne({ empId: 104 }));
// 8. Count experience > 3.
print("8. Experience > 3 count"); print(db.employees.countDocuments({ experience: { $gt: 3 } }));
// 9. Sort salary ascending.
print("9. Employees sorted by salary ascending"); db.employees.find().sort({ salary: 1 }).forEach(printjson);
// 10. Delete empId 102.
print("10. Delete empId 102"); printjson(db.employees.deleteOne({ empId: 102 }));
print("Remaining employees"); db.employees.find().forEach(printjson);
