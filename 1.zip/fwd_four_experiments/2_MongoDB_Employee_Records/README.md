# Assignment 2 — MongoDB Employee Records

**Database:** `companyDB` · **Collection:** `employees`

1. Install and start MongoDB Server.
2. Open a terminal and run `mongosh` from this folder, or execute `mongosh < employee_records.js`.
3. The script drops and recreates `employees` so every run starts from the same five records. Do not run it against important existing data.

The script demonstrates `insertMany`, `find`, `$gte`, `$ne`, `$in`, `updateOne` with `$inc`, `countDocuments` with `$gt`, `sort`, and `deleteOne`.
