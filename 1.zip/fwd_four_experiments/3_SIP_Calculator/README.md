# Assignment 3 — SIP Calculator using React and Tailwind CSS

### Run
```bash
npm install
npm run dev
```
Open the Vite URL shown in the terminal. Includes Home/calculator, SIP Guide, Benefits, About and a 404 route. The calculator uses the monthly SIP formula and handles a 0% annual return separately to avoid division by zero.
